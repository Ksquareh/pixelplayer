PIXELPLAYER — LOCAL VIDEO PLAYER

Open index.html or host this folder as a static website.
MP4/H.264 is the most broadly supported format; MKV support depends on browser codecs.

